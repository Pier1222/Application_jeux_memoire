package memory.bestmemorygames.nombres;

public class Control {
    protected Model model;
    protected VueNombres vue;

    public Control(Model model, VueNombres vue) {
        this.model = model;
        this.vue = vue;
    }
}
