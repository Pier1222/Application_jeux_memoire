package memory.bestmemorygames.piano;

public enum Couleur {
	
	BLANC,
	NOIR,
	;

}
