package memory.bestmemorygames.boulier;

public class Control {
    Model m;
    Vue v;

    public Control(Model m, Vue v) {
        this.m = m;
        this.v = v;
    }
}
