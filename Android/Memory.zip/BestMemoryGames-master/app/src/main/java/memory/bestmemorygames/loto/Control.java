package memory.bestmemorygames.loto;

public class Control {
    Model m;
    VueLoto v;

    public Control(Model m, VueLoto v) {
        this.m = m;
        this.v = v;
    }
}
