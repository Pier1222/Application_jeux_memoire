package com.example.adrie.piano2.controller;

/*import android.media.MediaPlayer;



public class Son extends MediaPlayer {
        private URL u1;//l'url de ton fichier son
        private AudioClip s1;//le son créé depuis ton url

        public Son(String nomFichier) {
            try {
                u1 = getClass().getResource(nomFichier);
            } catch(NullPointerException e) {
                System.out.println("FICHIER SON NON TROUVE!");
            }

            s1 = Applet.newAudioClip(u1);;
        }
        public void jouer() {
            s1.play();
        }

        public void jouerEnBoucle() {
            s1.loop();
        }

        public void arreter() {
            s1.stop();
        }
}*/
