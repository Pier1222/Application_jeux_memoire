package com.example.adrie.piano2.controller;

public enum Couleur {
	
	BLANC,
	NOIR,
	;

}
