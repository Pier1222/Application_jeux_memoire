package com.example.girardot.piano;

public enum Couleur {
	
	BLANC,
	NOIR,
	;

}
