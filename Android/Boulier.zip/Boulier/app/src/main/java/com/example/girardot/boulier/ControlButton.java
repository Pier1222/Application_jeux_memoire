/*package com.example.girardot.boulier;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class ControlButton extends Control implements View.OnClickListener {

    public ControlButton(Model m, Vue v){
        super(m, v);
        v.setClickListener(this);
    }

    @Override
    public void onClick(View view) {
        System.out.println("Truc");
    }
}*/

