/*package com.example.girardot.boulier;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Boulier extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_boulier);
        Model m = new Model();
        ControlGroup cg = new ControlGroup(m);
    }
}*/
