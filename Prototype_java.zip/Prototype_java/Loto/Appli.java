
class Appli {
 
  public static void main(String[] args) {
 
    Model m = new Model();
    ControlGroup cm = new ControlGroup(m);
  }
}