
public enum Couleur {
	
	BLANC,
	NOIR,
	;

}
