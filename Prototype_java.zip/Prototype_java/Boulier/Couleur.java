
public enum Couleur {
	
	VIDE, //Pas de couleur (état des boules du bas en début de partie)
	BLEU,
	JAUNE,
	ROUGE,
	VERT,
	VIOLET,
	;

}
